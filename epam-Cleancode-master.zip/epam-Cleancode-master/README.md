# epam-Cleancode
epam week4 hometask - clean code and serialization
